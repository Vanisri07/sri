from flask import Flask,render_template,request,redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app=Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///data.db'
db=SQLAlchemy(app)

class Details(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    ssnId = db.Column(db.Integer,nullable=False,default='ssn')
    customerId = db.Column(db.Integer,nullable=False,default='custId')
    customerName = db.Column(db.String(10),nullable=False,default='custName')
    address = db.Column(db.Text,nullable=False,default='address')
    age = db.Column(db.Integer,nullable=False,default='age')
    accountType = db.Column(db.String(10),nullable=False,default='accType')
    accountId = db.Column(db.Integer,nullable=False,default='accId')
    amount = db.Column(db.Integer,nullable=False,default='amt')
    

    def __repr__(self):
        return 'Details' + str(self.id)

class Status(db.Model):
    status_id=db.Column(db.Integer,primary_key=True)
    message=db.Column(db.Text,nullable=False,default='address')
    Last_updated = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

#  Create Customer
@app.route('/createCustomer', methods=['GET', 'POST'])
def createCustomer():

    if request.method == 'POST':
        post_id = request.form['ssnId']
        post_name = request.form['customerName']
        post_age = request.form['age']
        post_address = request.form['address']
        new_post = Details(ssnId=post_id, customerName=post_name, age=post_age,address=post_address)
        db.session.add(new_post)
        db.session.commit()
        return redirect('/createCustomer')
    else:
        all_posts = Details.query.all()
        return render_template('createCustomer.html', createCustomer=all_posts)


#  Delete Account	
@app.route('/deleteAccount',methods=['GET','POST'])
def delete_account():
    if request.method== 'POST':
        post_title=request.form['accountId']
        user = Details.query.filter_by(accountId=post_title).first_or_404()
        db.session.delete(user)
        db.session.commit()
        return redirect('/deleteAccount')
        return render_template('deleteAccount.html',deleteAccount=user)
    else:
        all_posts=Details.query.all()
        return render_template('deleteAccount.html',deleteAccount=all_posts)

#  Customer Search		
@app.route('/customerSearch', methods=['GET', 'POST'])
def customerSearch():

    if request.method == 'POST':
        post_id = request.form['customerId']
        new_post = Details(customerId=post_id)
        db.session.add(new_post)
        db.session.commit()
        return redirect('/customerSearch')
        db.session.delete(new_post)
        db.session.commit()
        
        
    else:
        all_posts = Details.query.all()
        return render_template('customerSearch.html', customerSearch=all_posts)
	
# Account Search	
@app.route('/accountSearch', methods=['GET', 'POST'])
def accountSearch():

    if request.method == 'POST':
        post_id = request.form['accountId']
        new_post = Details(accountId=post_id)
        db.session.add(new_post)
        db.session.commit()
        return redirect('/accountSearch')
        db.session.delete(new_post)
        db.session.commit()
        
        
    else:
        all_posts = Details.query.all()
        return render_template('accountSearch.html', accountSearch=all_posts)
# Create Account
@app.route('/createAccount', methods=['GET', 'POST'])
def createAccount():
    
    if request.method == 'POST':
        post_customerId = request.form['customerId']
        post=Details.query.filter_by(customerId=post_customerId).first_or_404()
        post.accountType=request.form['accountType']
        post.amount=request.form['amount']
        db.session.commit()
        return redirect('/createAccount')
    else:
        all_posts=Details.query.all()
        return render_template('createAccount.html', createAccount=all_posts)

# Delete Customer
@app.route('/deleteCustomer',methods=['GET','POST'])
def deleteCustomer():
    if request.method== 'POST':
        post_id=request.form['ssnId']
        user = Details.query.filter_by(ssnId=post_id).first_or_404()
        db.session.delete(user)
        db.session.commit()
        return redirect('/deleteCustomer')
        return render_template('deleteCustomer.html',deleteCustomer=user)
    else:
        all_posts=Details.query.all()
        return render_template('deleteCustomer.html',deleteCustomer=all_posts)

@app.route('/updateCustomer', methods=['GET', 'POST'])
def updateCustomer():

    if request.method == 'POST':
        post_id = request.form['ssnId']
        new_post = Details(ssnId=post_id)
        
        
    else:
        all_posts = Details.query.all()
        return render_template('updateCustomer.html', updateCustomer=all_posts)


@app.route('/updateCustomer/<int:ssnId>')
def update(ssnId):
    post = Details.query.filter_by(ssnId)
    if request.method == 'POST':
        post.customerName = request.form['customerName']
        post.address = request.form['address']
        post.age = request.form['age']
        db.session.commit()
        return redirect('/updateCustomer/us.ssnId')
    else:
        return render_template('update.html', post=post)


